package org.xortican.model;

public class BookingDetailsPojo {
String name;
String email;
String mobile;
String date;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getDrname() {
	return drname;
}
public void setDrname(String drname) {
	this.drname = drname;
}
public String getDrmail() {
	return drmail;
}
public void setDrmail(String drmail) {
	this.drmail = drmail;
}
String time;
String drname;
String drmail;
}
