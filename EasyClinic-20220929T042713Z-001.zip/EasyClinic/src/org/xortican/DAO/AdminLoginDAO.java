package org.xortican.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.xortican.model.Adminpojo;
import org.xortican.util.JdbcConnec;

public class AdminLoginDAO {
	public Connection con;
	  public AdminLoginDAO() throws ClassNotFoundException, SQLException
	  {
	 con=JdbcConnec.getConnection();
	  }
	  public List<Adminpojo> checkCredentials() throws SQLException {
			// TODO Auto-generated method stub
			List<Adminpojo> list=new ArrayList<>();
			
			System.out.println("datas saved success " + list);
			
			PreparedStatement ps= con.prepareStatement("select * from admindetails");
			System.out.println(ps);
			
			ResultSet rs= ps.executeQuery();
			
			while (rs.next()){
				System.out.println(rs.getString("Adminname"));
				
				Adminpojo ap=new Adminpojo();
				ap.setAdminname(rs.getString("Adminname"));
				ap.setPassword(rs.getString("Password"));
				
				list.add(ap);
			}
			return list;
			
			
			
	  }

}
