package org.xortican.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.xortican.model.UserDetailsPojo;
import org.xortican.util.JdbcConnec;

public class UserDetailsDAO {
	public static Connection con;

	public UserDetailsDAO() throws ClassNotFoundException, SQLException
	{
		 con = JdbcConnec.getConnection();
	}

	public List<UserDetailsPojo> getDetailsList() throws SQLException {

		List<UserDetailsPojo> userDetaillist = new ArrayList<>();
		PreparedStatement pst = con
				.prepareStatement("SELECT * FROM userinsert");
		System.out.println("AccountDetailsDAO | getDetailsList() | connection"
				+ con);
		System.out.println(pst);
		ResultSet rs = pst.executeQuery();

		while (rs.next()) {
			UserDetailsPojo userDetails = new UserDetailsPojo();
			userDetails.setId(rs.getString("id"));
			userDetails.setName(rs.getString("name"));
			System.out.println("AccountDetailsDAO | getDetailsList() | in result set" + rs.getString("name"));
			userDetails.setEmail(rs.getString("email"));
			userDetails.setAge(rs.getString("age"));
			userDetails.setSex(rs.getString("sex"));
			userDetails.setAddress(rs.getString("address"));
			userDetails.setMobileno(rs.getString("mobileno"));
			userDetails.setDises(rs.getString("dises"));
			userDetails.setPrevious(rs.getString("previous"));
			userDetails.setDrname(rs.getString("drname"));
			userDetaillist.add(userDetails);

		}

		return userDetaillist;


	}
public void update (UserDetailsPojo po) throws SQLException {
		
		PreparedStatement pst = con.prepareStatement("update userinsert set  id=?,name=?, age=?,sex=?,address=?,mobileno=?,dises=?,previous=?,drname=? where email=?");
		pst.setString(1,po.getId());
		pst.setString(2,po.getName());
	    pst.setString(3,po.getAge());
		pst.setString(4, po.getSex());
		pst.setString(5, po.getAddress());
		pst.setString(6, po.getMobileno());
		pst.setString(7, po.getDises());
		pst.setString(8, po.getPrevious());
		pst.setString(9, po.getDrname());
		
		pst.setString(10,po.getEmail());
		
		int i = pst.executeUpdate();
		System.out.println("updated");
	
}}
