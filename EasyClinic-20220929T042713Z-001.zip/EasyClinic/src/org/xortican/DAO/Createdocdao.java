package org.xortican.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.xortican.model.Createdocpojo;
import org.xortican.util.JdbcConnec;




public class Createdocdao {
	
public static Connection con;
	
	public Createdocdao() throws ClassNotFoundException, SQLException
	{
		con = JdbcConnec.getConnection();
	}
	
	 public void insert (Createdocpojo po) throws SQLException {
		
		PreparedStatement ps=con.prepareStatement("Insert into doctordetails values(?,?,?,?,?)");
		
		
		ps.setString(1,po.getName());
		ps.setString(2,po.getEmail());
		ps.setString(3,po.getMobile());
		ps.setString(4, po.getSpecialist());
		ps.setString(5, po.getLocation());
		
		int i = ps.executeUpdate();	
	}
	public void update (Createdocpojo po) throws SQLException {
		
		PreparedStatement pst = con.prepareStatement("update Doctordetails set  name=?, mobile=?,specialist=?,location=? where email=?");
		
		pst.setString(1,po.getName());
	    pst.setString(2,po.getMobile());
		pst.setString(3, po.getSpecialist());
		pst.setString(4, po.getLocation());
		pst.setString(5,po.getEmail());
		
		int i = pst.executeUpdate();
		System.out.println("updated");
	}
	
	            
	        }

