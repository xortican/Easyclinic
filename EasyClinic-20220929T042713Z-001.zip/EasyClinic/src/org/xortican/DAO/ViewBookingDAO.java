package org.xortican.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.xortican.model.BookingDetailsPojo;
import org.xortican.util.JdbcConnec;

public class ViewBookingDAO {
public static Connection con;
	
	public ViewBookingDAO() throws ClassNotFoundException, SQLException
	{
		 con = JdbcConnec.getConnection();
	}

	public List<BookingDetailsPojo> getDetailsList() throws SQLException {

		List<BookingDetailsPojo> bookingDetaillist = new ArrayList<>();
		PreparedStatement pst = con
				.prepareStatement("SELECT * FROM bookingdetails");
		System.out.println("AccountDetailsDAO | getDetailsList() | connection"
				+ con);
		System.out.println(pst);
		ResultSet rs = pst.executeQuery();

		while (rs.next()) {
			BookingDetailsPojo bookingDetails = new BookingDetailsPojo();
			bookingDetails.setName(rs.getString("name"));
			System.out.println("AccountDetailsDAO | getDetailsList() | in result set" + rs.getString("name"));
			bookingDetails.setEmail(rs.getString("email"));
			bookingDetails.setMobile(rs.getString("mobile"));
			bookingDetails.setDate(rs.getString("date"));
			bookingDetails.setTime(rs.getString("time"));
			bookingDetails.setDrname(rs.getString("drname"));
			bookingDetails.setDrmail(rs.getString("drmail"));
			bookingDetaillist.add(bookingDetails);

		}

		return bookingDetaillist;

	}
}
