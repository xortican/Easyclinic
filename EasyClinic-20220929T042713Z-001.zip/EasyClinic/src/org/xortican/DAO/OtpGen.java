package org.xortican.DAO;

import java.util.Random;

import org.xortican.util.EmailUtil;



public class OtpGen {

	public static char[] generateOTP(int length) {
	      String numbers = "1234567890";
	      String name ="abcd";
	      String location ="qwerty";
	      String type =numbers.substring(0,4)+name.substring(0,3)+location.substring(2,4);
	      Random random = new Random();
	      char[] otp = new char[length];

	      for(int i = 0; i< length ; i++) {
	         otp[i] = type.charAt(random.nextInt(type.length()));
	      }
	      
	      return otp;
	      
     
}
}
