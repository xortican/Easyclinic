package org.xortican.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.xortican.DAO.AdminLoginDAO;
import org.xortican.model.Adminpojo;


/**
 * Servlet implementation class AdminLoginServlet
 */
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String username=request.getParameter("Adminname");
		String password=request.getParameter("Password");
		System.out.println("enter the Servlet");
		String forward = "";
		AdminLoginDAO loginDao;
		try {
			loginDao = new AdminLoginDAO();
			List<Adminpojo> li=loginDao.checkCredentials();
			
			for(Adminpojo i: li) {
				System.out.println(i.getAdminname());
				
				if(username.equalsIgnoreCase(i.getAdminname()) && password.equalsIgnoreCase(i.getPassword())) {
					forward = "AdminHome.jsp";
					break;
				}
				else if(username.equalsIgnoreCase(i.getAdminname()) && password!=i.getPassword()){
					forward = "InvalidPass.jsp";
					break;
					
				}
				else if(username!=i.getAdminname() && password.equalsIgnoreCase(i.getPassword())){
					forward = "InvalidUser.jsp";
					break;
				}
				else  {
						
							forward = "DoctorLoginFailed.jsp";
						}
											
				
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
			RequestDispatcher rd=request.getRequestDispatcher(forward);
			rd.forward(request, response);
	
	
	}

}
