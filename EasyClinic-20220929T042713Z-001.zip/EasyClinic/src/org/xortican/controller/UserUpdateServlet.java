package org.xortican.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.xortican.DAO.UserDetailsDAO;
import org.xortican.model.UserDetailsPojo;




/**
 * Servlet implementation class UserUpdateServlet
 */
@WebServlet("/UserUpdateServlet")
public class UserUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String age=request.getParameter("age");
		String sex=request.getParameter("sex");
		String address=request.getParameter("address");
		String mobileno=request.getParameter("mobileno");
		String disease=request.getParameter("disease");
		String previous=request.getParameter("previous");
		String drname=request.getParameter("drname");
	/*	
		try {
			Createdocdao.update1(name,email,mobile);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
UserDetailsPojo p=new UserDetailsPojo();
		
        p.setId(id);
		p.setName(name);
		p.setEmail(email);
		p.setAge(age);
		p.setSex(sex);
		p.setAddress(address);
		p.setMobileno(mobileno);
		p.setDises(disease);
		p.setPrevious(previous);
		p.setDrname(drname);
		
		try {
			UserDetailsDAO d=new UserDetailsDAO();
			System.out.println("hello");
			d.update(p);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("Insertsuccess.jsp");
			 dispatcher.forward(request, response);	
		} 
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
