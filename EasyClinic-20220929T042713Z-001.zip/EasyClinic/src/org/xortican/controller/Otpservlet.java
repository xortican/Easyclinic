package org.xortican.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.xortican.util.EmailUtil;
import org.xortican.util.JdbcConnec;

/**
 * Servlet implementation class Otpservlet
 */
@WebServlet("/Otpservlet")
public class Otpservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Otpservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		 
		int randomPin   =(int)(Math.random()*9000)+100000;
		String otp  =String.valueOf(randomPin);
		System.out.println(otp);
		
		String to =request.getParameter("email");
	
		
		try {
			EmailUtil.sent(to,otp);
			try {
				Connection con =JdbcConnec.getConnection();
				PreparedStatement pst = con.prepareStatement("insert into  doctorlogin values(?,?)");
				pst.setString(1, to);
				pst.setString(2, otp);
				int i=pst.executeUpdate();
				RequestDispatcher dispatcher = request.getRequestDispatcher("AdminHome.jsp");
				 dispatcher.forward(request, response);	
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	}

}
